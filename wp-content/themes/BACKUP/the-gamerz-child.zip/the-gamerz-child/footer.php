<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package The_Gamerz
 */

?>

	</div><!-- #content -->

	<footer>
			<div class="footer-ads-area clearfix">
					<div class="widget-first-image">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 paragraph-area">
							<?php dynamic_sidebar( 'Footer widget 1' ); ?>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 buying-guides">
						<?php dynamic_sidebar( 'Footer widget 2' ); ?>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 head-phones">
						<?php dynamic_sidebar( 'Footer widget 3' ); ?>
					</div>
			</div>
			<div style="clear: both;"></div>
			<div class="container">
				<div class="footer-widgets widget-heading clearfix">
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
						<?php dynamic_sidebar( 'Footer widget 4' ); ?>
					</div>
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
						<?php dynamic_sidebar( 'Footer widget 5' ); ?>
					</div>
					<div style="clear: both;" class="on-xs"></div>
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
						<?php dynamic_sidebar( 'Footer widget 6' ); ?>
						<?php dynamic_sidebar( 'Footer Social Media' ); ?>
					</div>
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
						<?php dynamic_sidebar( 'Footer widget 7' ); ?>
					</div>
				</div>
			</div>
			<div class="copyright">
				<?php dynamic_sidebar( 'Footer widget 8' ); ?>
			</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<div class="owl-carousel owl-theme owl-loaded owl-drag"><div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-1816px, 0px, 0px); transition: 0.25s; width: 3634px;"><div class="owl-item cloned" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=52" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item cloned" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=63" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item cloned" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-4/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product1.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-4/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=318" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product1.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=51" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=52" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item active" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=63" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item active" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-4/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product1.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-4/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=318" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item cloned active" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product1.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=51" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item cloned" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-2/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=52" class="cart_btn">buy it now</a></span></li></div></div><div class="owl-item cloned" style="width: 353.333px; margin-right: 10px;"><div class="item"><li class="slider-product-item"><span class="product_image"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/"><img src="http://site.startupbug.net:6999/mshop/wp-content/uploads/2017/06/product.png" class="center-block"></a></span><span class="product_title"><a href="http://site.startupbug.net:6999/mshop/product/iphone-5s-16-gb-copy-copy-copy/">iphone 5s 16 GB</a></span><span class="product_configuration">Apple iPhone 5S 16GB EE/Virgin Network</span><span class="desc">iPhone 5s features a 4-inch Retina display, an A7 chip with 64-bit d...</span><span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>99.00</span></span><span class="pro_btn"><a href="/mshop/?add-to-cart=63" class="cart_btn">buy it now</a></span></li></div></div></div></div><div class="owl-nav"><div class="owl-prev"><i class="fa fa-chevron-left" aria-hidden="true"></i></div><div class="owl-next"><i class="fa fa-chevron-right" aria-hidden="true"></i></div></div><div class="owl-dots"><div class="owl-dot active"><span></span></div><div class="owl-dot"><span></span></div></div></div>


<?php /* <!-- 
<script>
if(!window.jQuery)
{
   var script = document.createElement('script');
   script.type = "text/javascript";
   script.src = "<?= get_bloginfo( 'stylesheet_directory' ); ?>/assets/js/jquery-1.12.4.min.js";
   document.getElementsByTagName('footer')[0].appendChild(script);
}
</script> --> */ ?>

<script>
	if (typeof jQuery == 'undefined') {  
    	  
    	var jq = document.createElement('script'); jq.type = 'text/javascript';
		jq.src = "<?= get_bloginfo( 'stylesheet_directory' ); ?>/assets/js/jquery-1.12.4.min.js";
		document.getElementsByTagName('footer')[0].appendChild(jq);

	}
</script>

 	<script src="<?= get_bloginfo( 'stylesheet_directory' ); ?>/assets/libraries/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?= get_bloginfo( 'stylesheet_directory' ); ?>/assets/js/jquery.iframetracker.js"></script>
	<script src="<?= get_bloginfo( 'stylesheet_directory' ); ?>/assets/js/main.js"></script>
<script>
 jQuery('#adv_team_4_columns_carousel').carousel({
    pause: true,
    interval: false,
		responsive:{
		        0:{
		            items:3
		        },
		        600:{
		            items:3
		        },
		        1000:{
		            items:3
		        }
		    }
  });
		
</script>
<?php wp_footer(); ?>

</body>
</html>
