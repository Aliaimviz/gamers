<?php

 /* Template Name: Reviews */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<div class="magazine-single-page buying-guides-page">

				<div class="magazine-guides-banner">
					<h1>le miglori currie da gaming inverno 2017</h1>
				</div>
				<div id="sticky-anchor"></div>

				<div class="container mt-26 clearfix pad0">
					
					<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 pad0 w316 for-affix">&nbsp;</div>
<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 pad0 w316 right-sidebar-gadget">
						<div class="gadgets">
							<h2 class="Raleway"> <i class="fa fa-mobile" aria-hidden="true"></i> Gadgets</h2>
							<div class="gadgets-content">
								<h3 class="Raleway name-title">now reading</h3>
								<p class="Raleway">
									Lorem Ipsum is simply dummy text of the printing and typesettin...
								</p>
							</div>

							<div class="row">
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 clearfix next-prev">
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
										<a rel="prev" class="Raleway semi-transparent-button right" href="#" title="Archieve"><i class="fa fa-angle-left" aria-hidden="true"></i> prev</a>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
										<a rel="next" href="#" class="Raleway semi-transparent-button left">next <i class="fa fa-angle-right" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
						</div>

						<div class="side-content">
							<h2 class="Raleway"> contents</h2>
							<div class="list-content">
								<ul id="navigation-ul">
									<li><a href="#">overview</a></li>
									<li><a href="#">rating</a></li>
									<li><a href="#">full article</a></li>
									<li><a href="#">custom anchor</a></li>
									<li><a href="#">another anchor</a></li>
									<li><a href="#">this menu is unique per post</a></li>
									<li><a href="#">updated</a></li>
									<li><a href="#">photos</a></li>
									<li><a href="#">final thoughts</a></li>
									<li><a href="#">comments</a></li>
								</ul>
							</div>
						</div>
					</div>
			<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 pad-r19-l17 content-single-magazine" style="float: right;">
			<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 pad-r19-l17 content-single-magazine">

						<div class="simple-heading-para-content">
							<h1>introduction</h1>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
						</div>

						<div class="simple-heading-para-content simple-content-2">
							<h1>how to choose best gaming headsets</h1>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<a href="#" class="simple-content-readmore">Read More</a>
						</div>

						<div class="image-text-quote">
							<img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/magazine-single-banner.png">
						</div>

					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 pad0 magazine-detail-sidebar">
					
						<?php dynamic_sidebar( 'Magazine Buying Guide Sidebar' ); ?>
					</div>
					</div>		

    <div class="row" style="padding: 5px 0px 0 15px;">
        <div class="row">
		
		
		<style>


@media all and (max-width: 768px) {
  .carousel-showmanymoveone .carousel-inner > .active.left,
  .carousel-showmanymoveone .carousel-inner > .prev {
    left: -50%;
  }
  .carousel-showmanymoveone .carousel-inner > .active.right,
  .carousel-showmanymoveone .carousel-inner > .next {
    left: 50%;
  }
  .carousel-showmanymoveone .carousel-inner > .left,
  .carousel-showmanymoveone .carousel-inner > .prev.right,
  .carousel-showmanymoveone .carousel-inner > .active {
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner .cloneditem-1 {
    display: block;
  }
}



.team_columns_item_image:hover .row{
    border-bottom: 5px solid #3e8091;
    margin: 0px 0px;
}
.team_columns_item_image .row{
    border-bottom: 5px solid #cacaca;
    margin: 0px 0px;
}
           .carousel-showmanymoveone .cloneditem-1,
          .carousel-showmanymoveone .cloneditem-2,
          .carousel-showmanymoveone .cloneditem-3,
          .carousel-showmanymoveone .cloneditem-4,
          .carousel-showmanymoveone .cloneditem-5,
          .carousel-showmanymoveone .cloneditem-6,
          .carousel-showmanymoveone .cloneditem-7,
          .carousel-showmanymoveone .cloneditem-8,
          .carousel-showmanymoveone .cloneditem-9

          {
              display: none;

          }


        @media all and (min-width: 768px) and (transform-3d), all and (min-width: 768px) and (-webkit-transform-3d) {


  .carousel-showmanymoveone .carousel-inner > .item.active.right,
  .carousel-showmanymoveone .carousel-inner > .item.next {
    -webkit-transform: translate3d(50%, 0, 0);
    transform: translate3d(50%, 0, 0);
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner > .item.active.left,
  .carousel-showmanymoveone .carousel-inner > .item.prev {
    -webkit-transform: translate3d(-50%, 0, 0);
    transform: translate3d(-50%, 0, 0);
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner > .item.left,
  .carousel-showmanymoveone .carousel-inner > .item.prev.right,
  .carousel-showmanymoveone .carousel-inner > .item.active {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
    left: 0;
  }
}
@media all and (min-width: 992px) {
  .carousel-showmanymoveone .carousel-inner > .active.left,
  .carousel-showmanymoveone .carousel-inner > .prev {
    left: -32%;
  }
  .carousel-showmanymoveone .carousel-inner > .active.right,
  .carousel-showmanymoveone .carousel-inner > .next {
    left: 32%;
  }
  .carousel-showmanymoveone .carousel-inner > .left,
  .carousel-showmanymoveone .carousel-inner > .prev.right,
  .carousel-showmanymoveone .carousel-inner > .active {
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner .cloneditem-1,
  .carousel-showmanymoveone .carousel-inner .cloneditem-2
  {
    display: block;
  }
}
@media all and (min-width: 992px) and (transform-3d), all and (min-width: 992px) and (-webkit-transform-3d) {
  .carousel-showmanymoveone .carousel-inner > .item.active.right,
  .carousel-showmanymoveone .carousel-inner > .item.next {
    -webkit-transform: translate3d(30%, 0, 0);
    transform: translate3d(30%, 0, 0);
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner > .item.active.left,
  .carousel-showmanymoveone .carousel-inner > .item.prev {
    -webkit-transform: translate3d(-30%, 0, 0);
    transform: translate3d(-30%, 0, 0);
    left: 0;
  }
  .carousel-showmanymoveone .carousel-inner > .item.left,
  .carousel-showmanymoveone .carousel-inner > .item.prev.right,
  .carousel-showmanymoveone .carousel-inner > .item.active {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
    left: 0;
  }
}

.team_columns_item_image{
	width:30% !important;
}
.carousel-showmanymoveone .cloneditem-3{
    display: block;
    position: absolute;
    top: 0px;
    right: -200px;
	opacity:0.3;
	opacity:0.3;
		}
		
		#itemslider .carousel-control.right{
			background:none;
			    right: 95px;
    top: 30%;
    z-index: 999999;
		}
		#itemslider .carousel-control.left{
			background: none;
			left: 0px;
			top: 30%;
			z-index: 999999;
		}
		</style>
		<div class="col-xs-12 col-sm-12 col-md-12">
      <div class="carousel carousel-showmanymoveone slide" id="itemslider">
        <div class="carousel-inner">

          <div class="item active">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 1</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>
				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>
		      <div class="item">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 2</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
<div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>

				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>
		      <div class="item ">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 3</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                  <div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>
				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>
		     <div class="item ">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 4</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div><div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>
				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>
		     <div class="item ">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 5</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>

                  <div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>
				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>
		     <div class="item ">
            <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
              <a href="#"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01"></a>
             <div class="team_columns_item_caption">
                     <h4>MOUSE $300 6</h4>
                    
                  </div>
				  <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                  <div class="color-red">
                     <h4>Game Mouse 1</h4>
                  </div>
				  <div class="row">
                  	<div class="col-md-4 remove_padding">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4 remove_padding">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
            </div>
          </div>

     

     






        </div>

        <div id="slider-control">
        <a class="left carousel-control" href="#itemslider" data-slide="prev"><img src="http://site.startupbug.net:6999/thegamers/wp-content/themes/the-gamerz-child/assets/img/l.png" alt="Left" class="img-responsive"></a>
        <a class="right carousel-control" href="#itemslider" data-slide="next"><img src="http://site.startupbug.net:6999/thegamers/wp-content/themes/the-gamerz-child/assets/img/r.png" alt="Right" class="img-responsive"></a>
      </div>
      </div>
    </div>
		
		
		
		
		
		
      <div id="adv_team_4_columns_carousel" class="hide carousel slide four_shows_one_move team_columns_carousel_wrapper" data-ride="carousel" data-interval="2000" data-pause="hover">
         <!--========= Wrapper for slides =========-->
         <div class="carousel-inner" role="listbox">
            <!--========= 1st slide =========-->
			<div class="item active">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 1</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
		   <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 2</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
		   <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 3</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
		   <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 4</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
		   <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 5</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
		   <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 6</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
		   </div>
			
			
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 01">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 1</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 1</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 2</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 3</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-1">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 2</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 4</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 5</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 6</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-2">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 3</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 7</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 8</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 9</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
              
            </div>
            <!--========= 2nd slide =========-->
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 4</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 10</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 11</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 12</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-1">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                   <div class="team_columns_item_caption">
                     <h4>MOUSE $300 5</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 13</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 14</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 15</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-2">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                   <div class="team_columns_item_caption">
                     <h4>MOUSE $300 6</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 16</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 17</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 18</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
             
            </div>
            <!--========= 3rd slide =========-->
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 7</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 19</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 20</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 21</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-1">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                 <div class="team_columns_item_caption">
                     <h4>MOUSE $300 8</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 22</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 23</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 24</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               <div class="col-xs-12 col-sm-6 col-md-4 team_columns_item_image cloneditem-2">
                  <img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/mouse-png.png" alt="slider 02">
                  <div class="team_columns_item_caption">
                     <h4>MOUSE $300 9</h4>
                    
                  </div>
                   <div class="list-colums">
                     <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 25</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 26</h4>
                    <h4> <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Game Mouse 27</h4>
                    
                  </div>
                   <div class="row">
                  	<div class="col-md-4">
                  		<p>Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>	

                  	<div class="col-md-4">
                  	<p>	Best All Purpose Gaming Mouse </p>
                  	</div>
                  </div>
                         
               </div>
               
            </div>
           
         </div>
         <!--======= Navigation Buttons =========-->
         <!--======= Left Button =========-->
         <a class="left carousel-control team_columns_carousel_control_left adv_left" href="#adv_team_4_columns_carousel" role="button" data-slide="prev">
         <span class="fa fa-angle-left team_columns_carousel_control_icons" aria-hidden="true"></span>
         <span class="sr-only">Previous</span>
         </a>
         <!--======= Right Button =========-->
         <a class="right carousel-control team_columns_carousel_control_right adv_right" href="#adv_team_4_columns_carousel" role="button" data-slide="next">
         <span class="fa fa-angle-right team_columns_carousel_control_icons" aria-hidden="true"></span>
         <span class="sr-only">Next</span>
         </a>
      </div>
   </div>
    </div>


			<div class="col-md-12 comminucation-banner"></div>
		
					<div class="col-md-12 best-mouse"><h1>BEST MOUSE UNDER 	100 €</h1></div>
						<div class="simple-heading-para-content simple-content-2">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
						</div>


		<div class="row">
		<div class="col-md-4">
		<img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/slider-1.png" style="height: 350px;">	
		</div>
			<div class="col-md-8">
				<h1 class="title">TITLE TILTE TITLE</h1>
				<div class="row bg-red">
				<div class="col-md-3 after_block"><h5>Your</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon2-1.png" alt=""></div>
				<div class="col-md-6 after_block"><h5>G2A SCORE</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexagon.png" alt=""></div>
				<div class="col-md-3" ><h5 class="user-heading">USER</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon1.png" alt=""></div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Piattafarma </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Produttore </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> GENRE </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> SPEEDIZONE </h2><p>Play Station4</p></div>
					
				</div>
							
				</div>
			</div>



<div class="row" style="margin-bottom: 50px;">
<div class="col-md-4">
		<h4 class="title-game bottom-border">editors Don't like</h4>
		<div class="text-icons">
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>

		<h4 class="title-game bottom-border">editors like</h4>
		<div class="text-icons">
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>
			
		</div>
	
	<div class="col-md-8 ">
	<div class="top-bottum-border">
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/44.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer47.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer48.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer1.png" alt=""></div>
			
</div>



<div class="row tag-padding">
				<div class="col-md-6">
				<h6 class="title-game">Status</h6><p>LIVE</p>
				<h6 class="title-game">plattaforma</h6><p>SENZA</p><p>COOPERATIVO </p>
				<h6 class="title-game">SYSTEMA DI PAGAMENTO</h6><p>PAY TO PLAY</p><p>FREE TO PLAY</p>


				</div>
				<div class="col-md-6">
				<h6 class="title-game">DATA DI USCITA</h6><p>or TBA (To Be Announced)</p>
				<h6 class="title-game">MULTIPLAYER </h6><p>PC</p><p>MAC</p><p>PS4</p><p>XBOX ONE</p>
				<h6 class="title-game">AMBIENTAZIONE</h6><p>GUERRA</p><p>FANTASY</p>


				</div>	

	</div>
	<div style="text-align: center;margin-top: 10px;"><a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a></div>


							<div class="simple-heading-para-content simple-content-2">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<a href="#" class="simple-content-readmore"> Go To Page</a>
								<a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a>
							</div>



</div>
		
</div>









		<div class="row">
		<div class="col-md-4">
		<img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/slider-1.png" style="height: 350px;">	
		</div>
			<div class="col-md-8">
				<h1 class="title">TITLE TILTE TITLE</h1>
				<div class="row bg-red">
				<div class="col-md-3 after_block"><h5>Your</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon2-1.png" alt=""></div>
				<div class="col-md-6 after_block"><h5>G2A SCORE</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexagon.png" alt=""></div>
				<div class="col-md-3" ><h5 class="user-heading">USER</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon1.png" alt=""></div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Piattafarma </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Produttore </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> GENRE </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> SPEEDIZONE </h2><p>Play Station4</p></div>
					
				</div>
							
				</div>
			</div>



<div class="row" style="margin-bottom: 50px;">
<div class="col-md-4">
		<h4 class="title-game bottom-border">editors Don't like</h4>
		<div class="text-icons">
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>

		<h4 class="title-game bottom-border">editors like</h4>
		<div class="text-icons">
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>
			
		</div>
	
	<div class="col-md-8 ">
	<div class="top-bottum-border">
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/44.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer47.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer48.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer1.png" alt=""></div>
			
</div>



<div class="row tag-padding">
				<div class="col-md-6">
				<h6 class="title-game">Status</h6><p>LIVE</p>
				<h6 class="title-game">plattaforma</h6><p>SENZA</p><p>COOPERATIVO </p>
				<h6 class="title-game">SYSTEMA DI PAGAMENTO</h6><p>PAY TO PLAY</p><p>FREE TO PLAY</p>


				</div>
				<div class="col-md-6">
				<h6 class="title-game">DATA DI USCITA</h6><p>or TBA (To Be Announced)</p>
				<h6 class="title-game">MULTIPLAYER </h6><p>PC</p><p>MAC</p><p>PS4</p><p>XBOX ONE</p>
				<h6 class="title-game">AMBIENTAZIONE</h6><p>GUERRA</p><p>FANTASY</p>


				</div>	

	</div>
	<div style="text-align: center;margin-top: 10px;"><a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a></div>


							<div class="simple-heading-para-content simple-content-2">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<a href="#" class="simple-content-readmore"> Go To Page</a>
								<a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a>
							</div>



</div>
		
</div>













		<div class="row">
		<div class="col-md-4">
		<img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/slider-1.png" style="height: 350px;">	
		</div>
			<div class="col-md-8">
				<h1 class="title">TITLE TILTE TITLE</h1>
				<div class="row bg-red">
				<div class="col-md-3 after_block"><h5>Your</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon2-1.png" alt=""></div>
				<div class="col-md-6 after_block"><h5>G2A SCORE</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexagon.png" alt=""></div>
				<div class="col-md-3" ><h5 class="user-heading">USER</h5><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/hexgaon1.png" alt=""></div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Piattafarma </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> Produttore </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> GENRE </h2><p>Play Station4</p></div>
				<div class="col-md-3 col-xs-6"><h2 class="title-game"> SPEEDIZONE </h2><p>Play Station4</p></div>
					
				</div>
							
				</div>
			</div>



<div class="row">
<div class="col-md-4">
		<h4 class="title-game bottom-border">editors Don't like</h4>
		<div class="text-icons">
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-minus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>

		<h4 class="title-game bottom-border">editors like</h4>
		<div class="text-icons">
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Landrush Quickly </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>AI can Be bit single minded </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Team Bui </p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>No VR Support</p>
			<p><i class="fa fa-plus-square" aria-hidden="true"></i>Visulay A Bit Blind</p>
	
		</div>
			
		</div>
	
	<div class="col-md-8 ">
	<div class="top-bottum-border">
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/44.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer47.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer48.png" alt=""></div>
				<div class="col-md-3 col-xs-6"><img src="http://site.startupbug.net:6999/thegamers/wp-content/uploads/2017/09/layer1.png" alt=""></div>
			
</div>



<div class="row tag-padding">
				<div class="col-md-6">
				<h6 class="title-game">Status</h6><p>LIVE</p>
				<h6 class="title-game">plattaforma</h6><p>SENZA</p><p>COOPERATIVO </p>
				<h6 class="title-game">SYSTEMA DI PAGAMENTO</h6><p>PAY TO PLAY</p><p>FREE TO PLAY</p>


				</div>
				<div class="col-md-6">
				<h6 class="title-game">DATA DI USCITA</h6><p>or TBA (To Be Announced)</p>
				<h6 class="title-game">MULTIPLAYER </h6><p>PC</p><p>MAC</p><p>PS4</p><p>XBOX ONE</p>
				<h6 class="title-game">AMBIENTAZIONE</h6><p>GUERRA</p><p>FANTASY</p>


				</div>	

	</div>
	<div style="text-align: center;margin-top: 10px;"><a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a></div>


							<div class="simple-heading-para-content simple-content-2">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis repellat delectus, cum porro, culpa esse temporibus nam tempore maiores fugiat atque ipsum, et quaerat dicta voluptas veritatis voluptatem, ea consequuntur.</p>
							<a href="#" class="simple-content-readmore"> Go To Page</a>
								<a href="#" class="simple-content-readmore black-bg">Visit Offical Website</a>
							</div>


 <div class="pagination-wrap">
        <ul class="pagination pagination-v1">
          <li><a href="#">O</a></li>
          <li><a class="active" href="#">O</a></li>
          <li><a href="#">O</a></li>
          <li><a href="#">O</a></li>
          <li><a href="#">O</a></li>
        </ul>
      </div>
</div>
		
</div>

<div class="col-md-12 comminucation-banner2"></div>
		<div class="row comment">
	<div class="col-md-1" style="float: left;margin-left: 50px;"> <img alt="" src="http://0.gravatar.com/avatar/37c9fb2d6896e6dd97b1d46b08fd68ba?s=32&amp;d=mm&amp;r=g" srcset="http://0.gravatar.com/avatar/37c9fb2d6896e6dd97b1d46b08fd68ba?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo" height="32" width="32"></div>
	<div class="col-md-10" >

		<div id="comment_form">
			<div><h4><i class="fa fa-comments" aria-hidden="true"></i>Comment</h4></div>
	<div>
		<textarea rows="10" name="comment" id="comment" class="textarea" placeholder="Enter Your Comment Here"></textarea>
	</div>
	<div>
		<input type="text" name="name" id="name" value="" class="textbox" placeholder="Name">
	</div>
	<div>
		<input type="email" name="email" id="email" value="" class="textbox" placeholder="Email">
	</div>
	
	<div class="comment-footer">
		
		<ul class="comments_ul">
			<li><img alt="" src="http://0.gravatar.com/avatar/37c9fb2d6896e6dd97b1d46b08fd68ba?s=32&amp;d=mm&amp;r=g" srcset="http://0.gravatar.com/avatar/37c9fb2d6896e6dd97b1d46b08fd68ba?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo" height="32" width="32" style="border-radius: 15px;"></li>
			<li><i class="fa fa-user-o" aria-hidden="true"></i>JS</li>
			<li><i class="fa fa-user-o" aria-hidden="true"></i>Apri 13th, 2017 12:26</li>
		</ul>

		<p class="comment_para">Any1 played it ready? Is it worth buying?</p>


		<ul class="comments_rate_ul">
			<li>Rate this comment</li>
			<li>0 <i class="fa fa-thumbs-up" aria-hidden="true"></i></li>
			<li>0 <i class="fa fa-thumbs-down" aria-hidden="true"></i></li>
            <li><a href="#" class='comment-reply'>Reply</a> </li>
		</ul>


	</div>
</div>
	</div>
	</div>
			</div>
				
			</div>
			
		</div>


				</div>
				</div>
				</div>
			</div>
			

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();